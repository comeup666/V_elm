function hostpath() {
    var n = window.location.href,
    t = n.match("^(ftp|http|https|file)://([^/]+)(/.*)?(/.*)")[4];
    return t != "/" && (n = n.replace(t, "") + "/"),
    n
}
function Querystring() {
    for (var t, r = location.search.substring(1, location.search.length), i = r.split("&"), n = 0; n < i.length; n++) t = i[n].split("="),
    temp = unescape(t[0]).split("+"),
    name = temp.join(" "),
    temp = unescape(t[1]).split("+"),
    value = temp.join(" "),
    this[name] = value;
    this.get = Querystring_get
}
function Querystring_get(n, t) {
    var i = this[n];
    return i == null && (i = t),
    i
}
function getQuerystringVar(n) {
    var t = "";
    return window.location.search.indexOf(n + "=") != -1 && (t = window.location.search.substring(window.location.search.indexOf(n + "=") + n.length + 1, (window.location.search + "&").indexOf("&", window.location.search.indexOf(n + "=") + n.length))),
    t
}
function getQuerystringVarInString(n, t) {
    var i = "";
    return n.indexOf(t + "=") != -1 && (i = n.substring(n.indexOf(t + "=") + t.length + 1, (n + "&").indexOf("&", n.indexOf(t + "=") + t.length))),
    i
}
function replaceAll(n, t, i) {
    return n.replace(new RegExp(t, "g"), i)
}
function removeHtmlFromString(n) {
    var t = n;
    return t = replaceAll(t, "&", "&amp;"),
    t = replaceAll(t, "<", "&lt;"),
    replaceAll(t, ">", "&gt;")
}
function removeHtmlFromField(n) {
    var t = "";
    return t = n.value,
    t = replaceAll(t, "&", "&amp;"),
    t = replaceAll(t, "<", "&lt;"),
    t = replaceAll(t, ">", "&gt;"),
    n.value = t,
    t
}
function removeAmpersandFromString(n) {
    var t = n;
    return replaceAll(t, "&", "%26")
}
function cleanSearchTerm(n) {
    var t = n;
    return t = t.trim(),
    t = replaceAll(t, " & ", " and "),
    t = replaceAll(t, "&", " and "),
    t = replaceAll(t, "<", " less than "),
    t = replaceAll(t, ">", " greater than "),
    t = replaceAll(t, "/", " - "),
    t = replaceAll(t, "\\\\", " - "),
    t = replaceAll(t, "\\?", ""),
    t = replaceAll(t, "\\&", "and"),
    t = replaceAll(t, "%", " percent"),
    t = replaceAll(t, "\\*", ""),
    t = replaceAll(t, "@", "%40"),
    t = replaceAll(t, "\\.", " "),
    t = removeHtmlFromString(t),
    removeAmpersandFromString(t)
}
function ajax(n, t, i, r, u) {
    var f = window.XMLHttpRequest ? new XMLHttpRequest: new ActiveXObject("MSXML2.XMLHTTP.3.0");
    f.open("GET", n, !0);
    f.onreadystatechange = function() {
        f.readyState == 4 && f.status == 200 ? f.responseText ? r ? u ? i(f.responseXML.documentElement, r) : i(f.responseText, r) : u ? i(f.responseXML.documentElement) : i(f.responseText) : i("", r) : f.readyState == 4 && i("", r)
    };
    f.send(t)
}
function wrapYouTubePH() {
    $("img.ytvidPH").each(function(n, t) {
        var i = $(t);
        i.parent().hasClass("embed-container") || i.wrap('<div class="embed-container"><\/div>');
        i.next(".ytvidLogo").length || i.after('<img class="ytvidLogo" src="/images/logo/social/YouTubePlay.png"/>')
    })
}
function addBrandToQueryString(n) {
    var i = getQuerystringVar("brands"),
    t = i.toString();
    t.indexOf(n, 0) < 0 && (t.length > 0 ? (t += "," + n, t = replaceAll(t, ",,", ",")) : t = n);
    t != i && queryString.push("brands", t)
}
function removeBrandFromQueryString(n) {
    var i = getQuerystringVar("brands"),
    t = i.toString();
    t.indexOf(n, 0) > -1 && (t = replaceAll(t, n, ""), t = replaceAll(t, ",,", ","), t.startsWith(",") && (t = t == "," ? "": t.substr(1, t.length - 1)));
    t != i && queryString.push("brands", t);
    t = getQuerystringVar("brands");
    t.length == 0 && (history.replaceState(null, window.document.title, replaceAll(window.location.toString(), "&brands=", "")), history.replaceState(null, window.document.title, replaceAll(window.location.toString(), "\\?brands=&", "?")), history.replaceState(null, window.document.title, replaceAll(window.location.toString(), "\\?brands=", "")))
}
function cleanQueryStringIfAllBrands() {
    mwdata.brandsnames.toString().indexOf("marvin", 0) > -1 & mwdata.brandsnames.toString().indexOf("integrity", 0) > -1 & mwdata.brandsnames.toString().indexOf("infinity", 0) > -1 && (removeBrandFromQueryString("marvin"), removeBrandFromQueryString("integrity"), removeBrandFromQueryString("infinity"))
}
function addMenuToUrl(n) {
    var i = getQuerystringVar("menu"),
    t = i.toString();
    t.indexOf(n, 0) < 0 && (t = n);
    t != i && queryString.push("menu", t)
}
function removeMenuFromUrl(n) {
    var i = getQuerystringVar("menu"),
    t = i.toString();
    t.indexOf(n, 0) > -1 && (t = replaceAll(t, n, ""));
    t != i && queryString.push("menu", t)
}
function replaceAll(n, t, i) {
    return n.replace(new RegExp(t, "g"), i)
}
function getParameterByName(n) {
    n = n.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var i = new RegExp("[\\?&]" + n + "=([^&#]*)"),
    t = i.exec(location.search);
    return t === null ? "": decodeURIComponent(t[1].replace(/\+/g, " "))
}
function centerItem() {
    pageWidth >= 768 ? ($(".center-height").each(function() {
        var n = $(this),
        t = n.height(),
        i = n.parent().height(),
        r = i / 2 - t / 2;
        n.css("padding-top", r + "px")
    }), $(".center-width").each(function() {
        var n = $(this),
        t = n.width(),
        i = n.parent().width(),
        r = i / 2 - t / 2;
        n.css("margin-left", r + "px")
    })) : $(".center-height").removeAttr("style");
    $(".promo-copy").each(function() {
        var n = $(this),
        t = n.height(),
        i = n.parent().height(),
        r = i / 2 - t / 2 - 6;
        n.css("padding-top", r + "px")
    })
}
function pWH() {
    $(".par-wid-hgt").each(function() {
        var n = $(this),
        t = n.parent().height(),
        i = $chThis.parent().width();
        n.css
    })
}
var contentRotator, definitions, pageWidth, pageHeight, isIE, winScrollPos, $window;
if ("undefined" == typeof jQuery) throw new Error("Bootstrap's JavaScript requires jQuery"); +
function(n) {
    "use strict";
    var t = n.fn.jquery.split(" ")[0].split(".");
    if (t[0] < 2 && t[1] < 9 || 1 == t[0] && 9 == t[1] && t[2] < 1 || t[0] > 3) throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 4");
} (jQuery); +
function(n) {
    "use strict";
    function t() {
        var i = document.createElement("bootstrap"),
        n = {
            WebkitTransition: "webkitTransitionEnd",
            MozTransition: "transitionend",
            OTransition: "oTransitionEnd otransitionend",
            transition: "transitionend"
        };
        for (var t in n) if (void 0 !== i.style[t]) return {
            end: n[t]
        };
        return ! 1
    }
    n.fn.emulateTransitionEnd = function(t) {
        var i = !1,
        u = this,
        r;
        n(this).one("bsTransitionEnd",
        function() {
            i = !0
        });
        return r = function() {
            i || n(u).trigger(n.support.transition.end)
        },
        setTimeout(r, t),
        this
    };
    n(function() {
        n.support.transition = t();
        n.support.transition && (n.event.special.bsTransitionEnd = {
            bindType: n.support.transition.end,
            delegateType: n.support.transition.end,
            handle: function(t) {
                if (n(t.target).is(this)) return t.handleObj.handler.apply(this, arguments)
            }
        })
    })
} (jQuery); +
function(n) {
    "use strict";
    function u(i) {
        return this.each(function() {
            var r = n(this),
            u = r.data("bs.alert");
            u || r.data("bs.alert", u = new t(this));
            "string" == typeof i && u[i].call(r)
        })
    }
    var i = '[data-dismiss="alert"]',
    t = function(t) {
        n(t).on("click", i, this.close)
    },
    r;
    t.VERSION = "3.3.7";
    t.TRANSITION_DURATION = 150;
    t.prototype.close = function(i) {
        function e() {
            r.detach().trigger("closed.bs.alert").remove()
        }
        var f = n(this),
        u = f.attr("data-target"),
        r;
        u || (u = f.attr("href"), u = u && u.replace(/.*(?=#[^\s]*$)/, ""));
        r = n("#" === u ? [] : u);
        i && i.preventDefault();
        r.length || (r = f.closest(".alert"));
        r.trigger(i = n.Event("close.bs.alert"));
        i.isDefaultPrevented() || (r.removeClass("in"), n.support.transition && r.hasClass("fade") ? r.one("bsTransitionEnd", e).emulateTransitionEnd(t.TRANSITION_DURATION) : e())
    };
    r = n.fn.alert;
    n.fn.alert = u;
    n.fn.alert.Constructor = t;
    n.fn.alert.noConflict = function() {
        return n.fn.alert = r,
        this
    };
    n(document).on("click.bs.alert.data-api", i, t.prototype.close)
} (jQuery); +
function(n) {
    "use strict";
    function i(i) {
        return this.each(function() {
            var u = n(this),
            r = u.data("bs.button"),
            f = "object" == typeof i && i;
            r || u.data("bs.button", r = new t(this, f));
            "toggle" == i ? r.toggle() : i && r.setState(i)
        })
    }
    var t = function(i, r) {
        this.$element = n(i);
        this.options = n.extend({},
        t.DEFAULTS, r);
        this.isLoading = !1
    },
    r;
    t.VERSION = "3.3.7";
    t.DEFAULTS = {
        loadingText: "loading..."
    };
    t.prototype.setState = function(t) {
        var i = "disabled",
        r = this.$element,
        f = r.is("input") ? "val": "html",
        u = r.data();
        t += "Text";
        null == u.resetText && r.data("resetText", r[f]());
        setTimeout(n.proxy(function() {
            r[f](null == u[t] ? this.options[t] : u[t]);
            "loadingText" == t ? (this.isLoading = !0, r.addClass(i).attr(i, i).prop(i, !0)) : this.isLoading && (this.isLoading = !1, r.removeClass(i).removeAttr(i).prop(i, !1))
        },
        this), 0)
    };
    t.prototype.toggle = function() {
        var t = !0,
        i = this.$element.closest('[data-toggle="buttons"]'),
        n;
        i.length ? (n = this.$element.find("input"), "radio" == n.prop("type") ? (n.prop("checked") && (t = !1), i.find(".active").removeClass("active"), this.$element.addClass("active")) : "checkbox" == n.prop("type") && (n.prop("checked") !== this.$element.hasClass("active") && (t = !1), this.$element.toggleClass("active")), n.prop("checked", this.$element.hasClass("active")), t && n.trigger("change")) : (this.$element.attr("aria-pressed", !this.$element.hasClass("active")), this.$element.toggleClass("active"))
    };
    r = n.fn.button;
    n.fn.button = i;
    n.fn.button.Constructor = t;
    n.fn.button.noConflict = function() {
        return n.fn.button = r,
        this
    };
    n(document).on("click.bs.button.data-api", '[data-toggle^="button"]',
    function(t) {
        var r = n(t.target).closest(".btn");
        i.call(r, "toggle");
        n(t.target).is('input[type="radio"], input[type="checkbox"]') || (t.preventDefault(), r.is("input,button") ? r.trigger("focus") : r.find("input:visible,button:visible").first().trigger("focus"))
    }).on("focus.bs.button.data-api blur.bs.button.data-api", '[data-toggle^="button"]',
    function(t) {
        n(t.target).closest(".btn").toggleClass("focus", /^focus(in)?$/.test(t.type))
    })
} (jQuery); +
function(n) {
    "use strict";
    function i(i) {
        return this.each(function() {
            var u = n(this),
            r = u.data("bs.carousel"),
            f = n.extend({},
            t.DEFAULTS, u.data(), "object" == typeof i && i),
            e = "string" == typeof i ? i: f.slide;
            r || u.data("bs.carousel", r = new t(this, f));
            "number" == typeof i ? r.to(i) : e ? r[e]() : f.interval && r.pause().cycle()
        })
    }
    var t = function(t, i) {
        this.$element = n(t);
        this.$indicators = this.$element.find(".carousel-indicators");
        this.options = i;
        this.paused = null;
        this.sliding = null;
        this.interval = null;
        this.$active = null;
        this.$items = null;
        this.options.keyboard && this.$element.on("keydown.bs.carousel", n.proxy(this.keydown, this));
        "hover" == this.options.pause && !("ontouchstart" in document.documentElement) && this.$element.on("mouseenter.bs.carousel", n.proxy(this.pause, this)).on("mouseleave.bs.carousel", n.proxy(this.cycle, this))
    },
    u,
    r;
    t.VERSION = "3.3.7";
    t.TRANSITION_DURATION = 600;
    t.DEFAULTS = {
        interval: 5e3,
        pause: "hover",
        wrap: !0,
        keyboard: !0
    };
    t.prototype.keydown = function(n) {
        if (!/input|textarea/i.test(n.target.tagName)) {
            switch (n.which) {
            case 37:
                this.prev();
                break;
            case 39:
                this.next();
                break;
            default:
                return
            }
            n.preventDefault()
        }
    };
    t.prototype.cycle = function(t) {
        return t || (this.paused = !1),
        this.interval && clearInterval(this.interval),
        this.options.interval && !this.paused && (this.interval = setInterval(n.proxy(this.next, this), this.options.interval)),
        this
    };
    t.prototype.getItemIndex = function(n) {
        return this.$items = n.parent().children(".item"),
        this.$items.index(n || this.$active)
    };
    t.prototype.getItemForDirection = function(n, t) {
        var i = this.getItemIndex(t),
        f = "prev" == n && 0 === i || "next" == n && i == this.$items.length - 1,
        r,
        u;
        return f && !this.options.wrap ? t: (r = "prev" == n ? -1 : 1, u = (i + r) % this.$items.length, this.$items.eq(u))
    };
    t.prototype.to = function(n) {
        var i = this,
        t = this.getItemIndex(this.$active = this.$element.find(".item.active"));
        if (! (n > this.$items.length - 1 || n < 0)) return this.sliding ? this.$element.one("slid.bs.carousel",
        function() {
            i.to(n)
        }) : t == n ? this.pause().cycle() : this.slide(n > t ? "next": "prev", this.$items.eq(n))
    };
    t.prototype.pause = function(t) {
        return t || (this.paused = !0),
        this.$element.find(".next, .prev").length && n.support.transition && (this.$element.trigger(n.support.transition.end), this.cycle(!0)),
        this.interval = clearInterval(this.interval),
        this
    };
    t.prototype.next = function() {
        if (!this.sliding) return this.slide("next")
    };
    t.prototype.prev = function() {
        if (!this.sliding) return this.slide("prev")
    };
    t.prototype.slide = function(i, r) {
        var e = this.$element.find(".item.active"),
        u = r || this.getItemForDirection(i, e),
        l = this.interval,
        f = "next" == i ? "left": "right",
        a = this,
        o,
        s,
        h,
        c;
        return u.hasClass("active") ? this.sliding = !1 : (o = u[0], s = n.Event("slide.bs.carousel", {
            relatedTarget: o,
            direction: f
        }), (this.$element.trigger(s), !s.isDefaultPrevented()) ? ((this.sliding = !0, l && this.pause(), this.$indicators.length) && (this.$indicators.find(".active").removeClass("active"), h = n(this.$indicators.children()[this.getItemIndex(u)]), h && h.addClass("active")), c = n.Event("slid.bs.carousel", {
            relatedTarget: o,
            direction: f
        }), n.support.transition && this.$element.hasClass("slide") ? (u.addClass(i), u[0].offsetWidth, e.addClass(f), u.addClass(f), e.one("bsTransitionEnd",
        function() {
            u.removeClass([i, f].join(" ")).addClass("active");
            e.removeClass(["active", f].join(" "));
            a.sliding = !1;
            setTimeout(function() {
                a.$element.trigger(c)
            },
            0)
        }).emulateTransitionEnd(t.TRANSITION_DURATION)) : (e.removeClass("active"), u.addClass("active"), this.sliding = !1, this.$element.trigger(c)), l && this.cycle(), this) : void 0)
    };
    u = n.fn.carousel;
    n.fn.carousel = i;
    n.fn.carousel.Constructor = t;
    n.fn.carousel.noConflict = function() {
        return n.fn.carousel = u,
        this
    };
    r = function(t) {
        var o, r = n(this),
        u = n(r.attr("data-target") || (o = r.attr("href")) && o.replace(/.*(?=#[^\s]+$)/, "")),
        e,
        f;
        u.hasClass("carousel") && (e = n.extend({},
        u.data(), r.data()), f = r.attr("data-slide-to"), f && (e.interval = !1), i.call(u, e), f && u.data("bs.carousel").to(f), t.preventDefault())
    };
    n(document).on("click.bs.carousel.data-api", "[data-slide]", r).on("click.bs.carousel.data-api", "[data-slide-to]", r);
    n(window).on("load",
    function() {
        n('[data-ride="carousel"]').each(function() {
            var t = n(this);
            i.call(t, t.data())
        })
    })
} (jQuery); +
function(n) {
    "use strict";
    function r(t) {
        var i, r = t.attr("data-target") || (i = t.attr("href")) && i.replace(/.*(?=#[^\s]+$)/, "");
        return n(r)
    }
    function i(i) {
        return this.each(function() {
            var u = n(this),
            r = u.data("bs.collapse"),
            f = n.extend({},
            t.DEFAULTS, u.data(), "object" == typeof i && i); ! r && f.toggle && /show|hide/.test(i) && (f.toggle = !1);
            r || u.data("bs.collapse", r = new t(this, f));
            "string" == typeof i && r[i]()
        })
    }
    var t = function(i, r) {
        this.$element = n(i);
        this.options = n.extend({},
        t.DEFAULTS, r);
        this.$trigger = n('[data-toggle="collapse"][href="#' + i.id + '"],[data-toggle="collapse"][data-target="#' + i.id + '"]');
        this.transitioning = null;
        this.options.parent ? this.$parent = this.getParent() : this.addAriaAndCollapsedClass(this.$element, this.$trigger);
        this.options.toggle && this.toggle()
    },
    u;
    t.VERSION = "3.3.7";
    t.TRANSITION_DURATION = 350;
    t.DEFAULTS = {
        toggle: !0
    };
    t.prototype.dimension = function() {
        var n = this.$element.hasClass("width");
        return n ? "width": "height"
    };
    t.prototype.show = function() {
        var f, r, e, u, o, s;
        if (!this.transitioning && !this.$element.hasClass("in") && (r = this.$parent && this.$parent.children(".panel").children(".in, .collapsing"), !(r && r.length && (f = r.data("bs.collapse"), f && f.transitioning)) && (e = n.Event("show.bs.collapse"), this.$element.trigger(e), !e.isDefaultPrevented()))) {
            if (r && r.length && (i.call(r, "hide"), f || r.data("bs.collapse", null)), u = this.dimension(), this.$element.removeClass("collapse").addClass("collapsing")[u](0).attr("aria-expanded", !0), this.$trigger.removeClass("collapsed").attr("aria-expanded", !0), this.transitioning = 1, o = function() {
                this.$element.removeClass("collapsing").addClass("collapse in")[u]("");
                this.transitioning = 0;
                this.$element.trigger("shown.bs.collapse")
            },
            !n.support.transition) return o.call(this);
            s = n.camelCase(["scroll", u].join("-"));
            this.$element.one("bsTransitionEnd", n.proxy(o, this)).emulateTransitionEnd(t.TRANSITION_DURATION)[u](this.$element[0][s])
        }
    };
    t.prototype.hide = function() {
        var r, i, u;
        if (!this.transitioning && this.$element.hasClass("in") && (r = n.Event("hide.bs.collapse"), this.$element.trigger(r), !r.isDefaultPrevented())) return i = this.dimension(),
        this.$element[i](this.$element[i]())[0].offsetHeight,
        this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded", !1),
        this.$trigger.addClass("collapsed").attr("aria-expanded", !1),
        this.transitioning = 1,
        u = function() {
            this.transitioning = 0;
            this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")
        },
        n.support.transition ? void this.$element[i](0).one("bsTransitionEnd", n.proxy(u, this)).emulateTransitionEnd(t.TRANSITION_DURATION) : u.call(this)
    };
    t.prototype.toggle = function() {
        this[this.$element.hasClass("in") ? "hide": "show"]()
    };
    t.prototype.getParent = function() {
        return n(this.options.parent).find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]').each(n.proxy(function(t, i) {
            var u = n(i);
            this.addAriaAndCollapsedClass(r(u), u)
        },
        this)).end()
    };
    t.prototype.addAriaAndCollapsedClass = function(n, t) {
        var i = n.hasClass("in");
        n.attr("aria-expanded", i);
        t.toggleClass("collapsed", !i).attr("aria-expanded", i)
    };
    u = n.fn.collapse;
    n.fn.collapse = i;
    n.fn.collapse.Constructor = t;
    n.fn.collapse.noConflict = function() {
        return n.fn.collapse = u,
        this
    };
    n(document).on("click.bs.collapse.data-api", '[data-toggle="collapse"]',
    function(t) {
        var u = n(this);
        u.attr("data-target") || t.preventDefault();
        var f = r(u),
        e = f.data("bs.collapse"),
        o = e ? "toggle": u.data();
        i.call(f, o)
    })
} (jQuery); +
function(n) {
    "use strict";
    function r(t) {
        var i = t.attr("data-target"),
        r;
        return i || (i = t.attr("href"), i = i && /#[A-Za-z]/.test(i) && i.replace(/.*(?=#[^\s]*$)/, "")),
        r = i && n(i),
        r && r.length ? r: t.parent()
    }
    function u(t) {
        t && 3 === t.which || (n(o).remove(), n(i).each(function() {
            var u = n(this),
            i = r(u),
            f = {
                relatedTarget: this
            };
            i.hasClass("open") && (t && "click" == t.type && /input|textarea/i.test(t.target.tagName) && n.contains(i[0], t.target) || (i.trigger(t = n.Event("hide.bs.dropdown", f)), t.isDefaultPrevented() || (u.attr("aria-expanded", "false"), i.removeClass("open").trigger(n.Event("hidden.bs.dropdown", f)))))
        }))
    }
    function e(i) {
        return this.each(function() {
            var r = n(this),
            u = r.data("bs.dropdown");
            u || r.data("bs.dropdown", u = new t(this));
            "string" == typeof i && u[i].call(r)
        })
    }
    var o = ".dropdown-backdrop",
    i = '[data-toggle="dropdown"]',
    t = function(t) {
        n(t).on("click.bs.dropdown", this.toggle)
    },
    f;
    t.VERSION = "3.3.7";
    t.prototype.toggle = function(t) {
        var f = n(this),
        i,
        o,
        e;
        if (!f.is(".disabled, :disabled")) {
            if (i = r(f), o = i.hasClass("open"), u(), !o) {
                if ("ontouchstart" in document.documentElement && !i.closest(".navbar-nav").length && n(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(n(this)).on("click", u), e = {
                    relatedTarget: this
                },
                i.trigger(t = n.Event("show.bs.dropdown", e)), t.isDefaultPrevented()) return;
                f.trigger("focus").attr("aria-expanded", "true");
                i.toggleClass("open").trigger(n.Event("shown.bs.dropdown", e))
            }
            return ! 1
        }
    };
    t.prototype.keydown = function(t) {
        var e, o, s, h, f, u;
        if (/(38|40|27|32)/.test(t.which) && !/input|textarea/i.test(t.target.tagName) && (e = n(this), t.preventDefault(), t.stopPropagation(), !e.is(".disabled, :disabled"))) {
            if (o = r(e), s = o.hasClass("open"), !s && 27 != t.which || s && 27 == t.which) return 27 == t.which && o.find(i).trigger("focus"),
            e.trigger("click");
            h = " li:not(.disabled):visible a";
            f = o.find(".dropdown-menu" + h);
            f.length && (u = f.index(t.target), 38 == t.which && u > 0 && u--, 40 == t.which && u < f.length - 1 && u++, ~u || (u = 0), f.eq(u).trigger("focus"))
        }
    };
    f = n.fn.dropdown;
    n.fn.dropdown = e;
    n.fn.dropdown.Constructor = t;
    n.fn.dropdown.noConflict = function() {
        return n.fn.dropdown = f,
        this
    };
    n(document).on("click.bs.dropdown.data-api", u).on("click.bs.dropdown.data-api", ".dropdown form",
    function(n) {
        n.stopPropagation()
    }).on("click.bs.dropdown.data-api", i, t.prototype.toggle).on("keydown.bs.dropdown.data-api", i, t.prototype.keydown).on("keydown.bs.dropdown.data-api", ".dropdown-menu", t.prototype.keydown)
} (jQuery); +
function(n) {
    "use strict";
    function i(i, r) {
        return this.each(function() {
            var f = n(this),
            u = f.data("bs.modal"),
            e = n.extend({},
            t.DEFAULTS, f.data(), "object" == typeof i && i);
            u || f.data("bs.modal", u = new t(this, e));
            "string" == typeof i ? u[i](r) : e.show && u.show(r)
        })
    }
    var t = function(t, i) {
        this.options = i;
        this.$body = n(document.body);
        this.$element = n(t);
        this.$dialog = this.$element.find(".modal-dialog");
        this.$backdrop = null;
        this.isShown = null;
        this.originalBodyPad = null;
        this.scrollbarWidth = 0;
        this.ignoreBackdropClick = !1;
        this.options.remote && this.$element.find(".modal-content").load(this.options.remote, n.proxy(function() {
            this.$element.trigger("loaded.bs.modal")
        },
        this))
    },
    r;
    t.VERSION = "3.3.7";
    t.TRANSITION_DURATION = 300;
    t.BACKDROP_TRANSITION_DURATION = 150;
    t.DEFAULTS = {
        backdrop: !0,
        keyboard: !0,
        show: !0
    };
    t.prototype.toggle = function(n) {
        return this.isShown ? this.hide() : this.show(n)
    };
    t.prototype.show = function(i) {
        var r = this,
        u = n.Event("show.bs.modal", {
            relatedTarget: i
        });
        this.$element.trigger(u);
        this.isShown || u.isDefaultPrevented() || (this.isShown = !0, this.checkScrollbar(), this.setScrollbar(), this.$body.addClass("modal-open"), this.escape(), this.resize(), this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', n.proxy(this.hide, this)), this.$dialog.on("mousedown.dismiss.bs.modal",
        function() {
            r.$element.one("mouseup.dismiss.bs.modal",
            function(t) {
                n(t.target).is(r.$element) && (r.ignoreBackdropClick = !0)
            })
        }), this.backdrop(function() {
            var f = n.support.transition && r.$element.hasClass("fade"),
            u;
            r.$element.parent().length || r.$element.appendTo(r.$body);
            r.$element.show().scrollTop(0);
            r.adjustDialog();
            f && r.$element[0].offsetWidth;
            r.$element.addClass("in");
            r.enforceFocus();
            u = n.Event("shown.bs.modal", {
                relatedTarget: i
            });
            f ? r.$dialog.one("bsTransitionEnd",
            function() {
                r.$element.trigger("focus").trigger(u)
            }).emulateTransitionEnd(t.TRANSITION_DURATION) : r.$element.trigger("focus").trigger(u)
        }))
    };
    t.prototype.hide = function(i) {
        i && i.preventDefault();
        i = n.Event("hide.bs.modal");
        this.$element.trigger(i);
        this.isShown && !i.isDefaultPrevented() && (this.isShown = !1, this.escape(), this.resize(), n(document).off("focusin.bs.modal"), this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"), this.$dialog.off("mousedown.dismiss.bs.modal"), n.support.transition && this.$element.hasClass("fade") ? this.$element.one("bsTransitionEnd", n.proxy(this.hideModal, this)).emulateTransitionEnd(t.TRANSITION_DURATION) : this.hideModal())
    };
    t.prototype.enforceFocus = function() {
        n(document).off("focusin.bs.modal").on("focusin.bs.modal", n.proxy(function(n) {
            document === n.target || this.$element[0] === n.target || this.$element.has(n.target).length || this.$element.trigger("focus")
        },
        this))
    };
    t.prototype.escape = function() {
        this.isShown && this.options.keyboard ? this.$element.on("keydown.dismiss.bs.modal", n.proxy(function(n) {
            27 == n.which && this.hide()
        },
        this)) : this.isShown || this.$element.off("keydown.dismiss.bs.modal")
    };
    t.prototype.resize = function() {
        this.isShown ? n(window).on("resize.bs.modal", n.proxy(this.handleUpdate, this)) : n(window).off("resize.bs.modal")
    };
    t.prototype.hideModal = function() {
        var n = this;
        this.$element.hide();
        this.backdrop(function() {
            n.$body.removeClass("modal-open");
            n.resetAdjustments();
            n.resetScrollbar();
            n.$element.trigger("hidden.bs.modal")
        })
    };
    t.prototype.removeBackdrop = function() {
        this.$backdrop && this.$backdrop.remove();
        this.$backdrop = null
    };
    t.prototype.backdrop = function(i) {
        var e = this,
        f = this.$element.hasClass("fade") ? "fade": "",
        r,
        u;
        if (this.isShown && this.options.backdrop) {
            if (r = n.support.transition && f, this.$backdrop = n(document.createElement("div")).addClass("modal-backdrop " + f).appendTo(this.$body), this.$element.on("click.dismiss.bs.modal", n.proxy(function(n) {
                return this.ignoreBackdropClick ? void(this.ignoreBackdropClick = !1) : void(n.target === n.currentTarget && ("static" == this.options.backdrop ? this.$element[0].focus() : this.hide()))
            },
            this)), r && this.$backdrop[0].offsetWidth, this.$backdrop.addClass("in"), !i) return;
            r ? this.$backdrop.one("bsTransitionEnd", i).emulateTransitionEnd(t.BACKDROP_TRANSITION_DURATION) : i()
        } else ! this.isShown && this.$backdrop ? (this.$backdrop.removeClass("in"), u = function() {
            e.removeBackdrop();
            i && i()
        },
        n.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one("bsTransitionEnd", u).emulateTransitionEnd(t.BACKDROP_TRANSITION_DURATION) : u()) : i && i()
    };
    t.prototype.handleUpdate = function() {
        this.adjustDialog()
    };
    t.prototype.adjustDialog = function() {
        var n = this.$element[0].scrollHeight > document.documentElement.clientHeight;
        this.$element.css({
            paddingLeft: !this.bodyIsOverflowing && n ? this.scrollbarWidth: "",
            paddingRight: this.bodyIsOverflowing && !n ? this.scrollbarWidth: ""
        })
    };
    t.prototype.resetAdjustments = function() {
        this.$element.css({
            paddingLeft: "",
            paddingRight: ""
        })
    };
    t.prototype.checkScrollbar = function() {
        var n = window.innerWidth,
        t;
        n || (t = document.documentElement.getBoundingClientRect(), n = t.right - Math.abs(t.left));
        this.bodyIsOverflowing = document.body.clientWidth < n;
        this.scrollbarWidth = this.measureScrollbar()
    };
    t.prototype.setScrollbar = function() {
        var n = parseInt(this.$body.css("padding-right") || 0, 10);
        this.originalBodyPad = document.body.style.paddingRight || "";
        this.bodyIsOverflowing && this.$body.css("padding-right", n + this.scrollbarWidth)
    };
    t.prototype.resetScrollbar = function() {
        this.$body.css("padding-right", this.originalBodyPad)
    };
    t.prototype.measureScrollbar = function() {
        var n = document.createElement("div"),
        t;
        return n.className = "modal-scrollbar-measure",
        this.$body.append(n),
        t = n.offsetWidth - n.clientWidth,
        this.$body[0].removeChild(n),
        t
    };
    r = n.fn.modal;
    n.fn.modal = i;
    n.fn.modal.Constructor = t;
    n.fn.modal.noConflict = function() {
        return n.fn.modal = r,
        this
    };
    n(document).on("click.bs.modal.data-api", '[data-toggle="modal"]',
    function(t) {
        var r = n(this),
        f = r.attr("href"),
        u = n(r.attr("data-target") || f && f.replace(/.*(?=#[^\s]+$)/, "")),
        e = u.data("bs.modal") ? "toggle": n.extend({
            remote: !/#/.test(f) && f
        },
        u.data(), r.data());
        r.is("a") && t.preventDefault();
        u.one("show.bs.modal",
        function(n) {
            n.isDefaultPrevented() || u.one("hidden.bs.modal",
            function() {
                r.is(":visible") && r.trigger("focus")
            })
        });
        i.call(u, e, this)
    })
} (jQuery); +
function(n) {
    "use strict";
    function r(i) {
        return this.each(function() {
            var u = n(this),
            r = u.data("bs.tooltip"),
            f = "object" == typeof i && i; ! r && /destroy|hide/.test(i) || (r || u.data("bs.tooltip", r = new t(this, f)), "string" == typeof i && r[i]())
        })
    }
    var t = function(n, t) {
        this.type = null;
        this.options = null;
        this.enabled = null;
        this.timeout = null;
        this.hoverState = null;
        this.$element = null;
        this.inState = null;
        this.init("tooltip", n, t)
    },
    i;
    t.VERSION = "3.3.7";
    t.TRANSITION_DURATION = 150;
    t.DEFAULTS = {
        animation: !0,
        placement: "top",
        selector: !1,
        template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"><\/div><div class="tooltip-inner"><\/div><\/div>',
        trigger: "hover focus",
        title: "",
        delay: 0,
        html: !1,
        container: !1,
        viewport: {
            selector: "body",
            padding: 0
        }
    };
    t.prototype.init = function(t, i, r) {
        var f, e, u, o, s;
        if (this.enabled = !0, this.type = t, this.$element = n(i), this.options = this.getOptions(r), this.$viewport = this.options.viewport && n(n.isFunction(this.options.viewport) ? this.options.viewport.call(this, this.$element) : this.options.viewport.selector || this.options.viewport), this.inState = {
            click: !1,
            hover: !1,
            focus: !1
        },
        this.$element[0] instanceof document.constructor && !this.options.selector) throw new Error("`selector` option must be specified when initializing " + this.type + " on the window.document object!");
        for (f = this.options.trigger.split(" "), e = f.length; e--;) if (u = f[e], "click" == u) this.$element.on("click." + this.type, this.options.selector, n.proxy(this.toggle, this));
        else "manual" != u && (o = "hover" == u ? "mouseenter": "focusin", s = "hover" == u ? "mouseleave": "focusout", this.$element.on(o + "." + this.type, this.options.selector, n.proxy(this.enter, this)), this.$element.on(s + "." + this.type, this.options.selector, n.proxy(this.leave, this)));
        this.options.selector ? this._options = n.extend({},
        this.options, {
            trigger: "manual",
            selector: ""
        }) : this.fixTitle()
    };
    t.prototype.getDefaults = function() {
        return t.DEFAULTS
    };
    t.prototype.getOptions = function(t) {
        return t = n.extend({},
        this.getDefaults(), this.$element.data(), t),
        t.delay && "number" == typeof t.delay && (t.delay = {
            show: t.delay,
            hide: t.delay
        }),
        t
    };
    t.prototype.getDelegateOptions = function() {
        var t = {},
        i = this.getDefaults();
        return this._options && n.each(this._options,
        function(n, r) {
            i[n] != r && (t[n] = r)
        }),
        t
    };
    t.prototype.enter = function(t) {
        var i = t instanceof this.constructor ? t: n(t.currentTarget).data("bs." + this.type);
        return i || (i = new this.constructor(t.currentTarget, this.getDelegateOptions()), n(t.currentTarget).data("bs." + this.type, i)),
        t instanceof n.Event && (i.inState["focusin" == t.type ? "focus": "hover"] = !0),
        i.tip().hasClass("in") || "in" == i.hoverState ? void(i.hoverState = "in") : (clearTimeout(i.timeout), i.hoverState = "in", i.options.delay && i.options.delay.show ? void(i.timeout = setTimeout(function() {
            "in" == i.hoverState && i.show()
        },
        i.options.delay.show)) : i.show())
    };
    t.prototype.isInStateTrue = function() {
        for (var n in this.inState) if (this.inState[n]) return ! 0;
        return ! 1
    };
    t.prototype.leave = function(t) {
        var i = t instanceof this.constructor ? t: n(t.currentTarget).data("bs." + this.type);
        if (i || (i = new this.constructor(t.currentTarget, this.getDelegateOptions()), n(t.currentTarget).data("bs." + this.type, i)), t instanceof n.Event && (i.inState["focusout" == t.type ? "focus": "hover"] = !1), !i.isInStateTrue()) return clearTimeout(i.timeout),
        i.hoverState = "out",
        i.options.delay && i.options.delay.hide ? void(i.timeout = setTimeout(function() {
            "out" == i.hoverState && i.hide()
        },
        i.options.delay.hide)) : i.hide()
    };
    t.prototype.show = function() {
        var c = n.Event("show.bs." + this.type),
        l,
        p,
        e,
        w,
        h;
        if (this.hasContent() && this.enabled) {
            if (this.$element.trigger(c), l = n.contains(this.$element[0].ownerDocument.documentElement, this.$element[0]), c.isDefaultPrevented() || !l) return;
            var u = this,
            r = this.tip(),
            a = this.getUID(this.type);
            this.setContent();
            r.attr("id", a);
            this.$element.attr("aria-describedby", a);
            this.options.animation && r.addClass("fade");
            var i = "function" == typeof this.options.placement ? this.options.placement.call(this, r[0], this.$element[0]) : this.options.placement,
            v = /\s?auto?\s?/i,
            y = v.test(i);
            y && (i = i.replace(v, "") || "top");
            r.detach().css({
                top: 0,
                left: 0,
                display: "block"
            }).addClass(i).data("bs." + this.type, this);
            this.options.container ? r.appendTo(this.options.container) : r.insertAfter(this.$element);
            this.$element.trigger("inserted.bs." + this.type);
            var f = this.getPosition(),
            o = r[0].offsetWidth,
            s = r[0].offsetHeight;
            y && (p = i, e = this.getPosition(this.$viewport), i = "bottom" == i && f.bottom + s > e.bottom ? "top": "top" == i && f.top - s < e.top ? "bottom": "right" == i && f.right + o > e.width ? "left": "left" == i && f.left - o < e.left ? "right": i, r.removeClass(p).addClass(i));
            w = this.getCalculatedOffset(i, f, o, s);
            this.applyPlacement(w, i);
            h = function() {
                var n = u.hoverState;
                u.$element.trigger("shown.bs." + u.type);
                u.hoverState = null;
                "out" == n && u.leave(u)
            };
            n.support.transition && this.$tip.hasClass("fade") ? r.one("bsTransitionEnd", h).emulateTransitionEnd(t.TRANSITION_DURATION) : h()
        }
    };
    t.prototype.applyPlacement = function(t, i) {
        var r = this.tip(),
        l = r[0].offsetWidth,
        e = r[0].offsetHeight,
        o = parseInt(r.css("margin-top"), 10),
        s = parseInt(r.css("margin-left"), 10),
        h,
        f,
        u;
        isNaN(o) && (o = 0);
        isNaN(s) && (s = 0);
        t.top += o;
        t.left += s;
        n.offset.setOffset(r[0], n.extend({
            using: function(n) {
                r.css({
                    top: Math.round(n.top),
                    left: Math.round(n.left)
                })
            }
        },
        t), 0);
        r.addClass("in");
        h = r[0].offsetWidth;
        f = r[0].offsetHeight;
        "top" == i && f != e && (t.top = t.top + e - f);
        u = this.getViewportAdjustedDelta(i, t, h, f);
        u.left ? t.left += u.left: t.top += u.top;
        var c = /top|bottom/.test(i),
        a = c ? 2 * u.left - l + h: 2 * u.top - e + f,
        v = c ? "offsetWidth": "offsetHeight";
        r.offset(t);
        this.replaceArrow(a, r[0][v], c)
    };
    t.prototype.replaceArrow = function(n, t, i) {
        this.arrow().css(i ? "left": "top", 50 * (1 - n / t) + "%").css(i ? "top": "left", "")
    };
    t.prototype.setContent = function() {
        var n = this.tip(),
        t = this.getTitle();
        n.find(".tooltip-inner")[this.options.html ? "html": "text"](t);
        n.removeClass("fade in top bottom left right")
    };
    t.prototype.hide = function(i) {
        function f() {
            "in" != r.hoverState && u.detach();
            r.$element && r.$element.removeAttr("aria-describedby").trigger("hidden.bs." + r.type);
            i && i()
        }
        var r = this,
        u = n(this.$tip),
        e = n.Event("hide.bs." + this.type);
        if (this.$element.trigger(e), !e.isDefaultPrevented()) return u.removeClass("in"),
        n.support.transition && u.hasClass("fade") ? u.one("bsTransitionEnd", f).emulateTransitionEnd(t.TRANSITION_DURATION) : f(),
        this.hoverState = null,
        this
    };
    t.prototype.fixTitle = function() {
        var n = this.$element; (n.attr("title") || "string" != typeof n.attr("data-original-title")) && n.attr("data-original-title", n.attr("title") || "").attr("title", "")
    };
    t.prototype.hasContent = function() {
        return this.getTitle()
    };
    t.prototype.getPosition = function(t) {
        t = t || this.$element;
        var r = t[0],
        u = "BODY" == r.tagName,
        i = r.getBoundingClientRect();
        null == i.width && (i = n.extend({},
        i, {
            width: i.right - i.left,
            height: i.bottom - i.top
        }));
        var f = window.SVGElement && r instanceof window.SVGElement,
        e = u ? {
            top: 0,
            left: 0
        }: f ? null: t.offset(),
        o = {
            scroll: u ? document.documentElement.scrollTop || document.body.scrollTop: t.scrollTop()
        },
        s = u ? {
            width: n(window).width(),
            height: n(window).height()
        }: null;
        return n.extend({},
        i, o, s, e)
    };
    t.prototype.getCalculatedOffset = function(n, t, i, r) {
        return "bottom" == n ? {
            top: t.top + t.height,
            left: t.left + t.width / 2 - i / 2
        }: "top" == n ? {
            top: t.top - r,
            left: t.left + t.width / 2 - i / 2
        }: "left" == n ? {
            top: t.top + t.height / 2 - r / 2,
            left: t.left - i
        }: {
            top: t.top + t.height / 2 - r / 2,
            left: t.left + t.width
        }
    };
    t.prototype.getViewportAdjustedDelta = function(n, t, i, r) {
        var f = {
            top: 0,
            left: 0
        },
        e,
        u,
        o,
        s,
        h,
        c;
        return this.$viewport ? (e = this.options.viewport && this.options.viewport.padding || 0, u = this.getPosition(this.$viewport), /right|left/.test(n) ? (o = t.top - e - u.scroll, s = t.top + e - u.scroll + r, o < u.top ? f.top = u.top - o: s > u.top + u.height && (f.top = u.top + u.height - s)) : (h = t.left - e, c = t.left + e + i, h < u.left ? f.left = u.left - h: c > u.right && (f.left = u.left + u.width - c)), f) : f
    };
    t.prototype.getTitle = function() {
        var t = this.$element,
        n = this.options;
        return t.attr("data-original-title") || ("function" == typeof n.title ? n.title.call(t[0]) : n.title)
    };
    t.prototype.getUID = function(n) {
        do n += ~~ (1e6 * Math.random());
        while (document.getElementById(n));
        return n
    };
    t.prototype.tip = function() {
        if (!this.$tip && (this.$tip = n(this.options.template), 1 != this.$tip.length)) throw new Error(this.type + " `template` option must consist of exactly 1 top-level element!");
        return this.$tip
    };
    t.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".tooltip-arrow")
    };
    t.prototype.enable = function() {
        this.enabled = !0
    };
    t.prototype.disable = function() {
        this.enabled = !1
    };
    t.prototype.toggleEnabled = function() {
        this.enabled = !this.enabled
    };
    t.prototype.toggle = function(t) {
        var i = this;
        t && (i = n(t.currentTarget).data("bs." + this.type), i || (i = new this.constructor(t.currentTarget, this.getDelegateOptions()), n(t.currentTarget).data("bs." + this.type, i)));
        t ? (i.inState.click = !i.inState.click, i.isInStateTrue() ? i.enter(i) : i.leave(i)) : i.tip().hasClass("in") ? i.leave(i) : i.enter(i)
    };
    t.prototype.destroy = function() {
        var n = this;
        clearTimeout(this.timeout);
        this.hide(function() {
            n.$element.off("." + n.type).removeData("bs." + n.type);
            n.$tip && n.$tip.detach();
            n.$tip = null;
            n.$arrow = null;
            n.$viewport = null;
            n.$element = null
        })
    };
    i = n.fn.tooltip;
    n.fn.tooltip = r;
    n.fn.tooltip.Constructor = t;
    n.fn.tooltip.noConflict = function() {
        return n.fn.tooltip = i,
        this
    }
} (jQuery); +
function(n) {
    "use strict";
    function r(i) {
        return this.each(function() {
            var u = n(this),
            r = u.data("bs.popover"),
            f = "object" == typeof i && i; ! r && /destroy|hide/.test(i) || (r || u.data("bs.popover", r = new t(this, f)), "string" == typeof i && r[i]())
        })
    }
    var t = function(n, t) {
        this.init("popover", n, t)
    },
    i;
    if (!n.fn.tooltip) throw new Error("Popover requires tooltip.js");
    t.VERSION = "3.3.7";
    t.DEFAULTS = n.extend({},
    n.fn.tooltip.Constructor.DEFAULTS, {
        placement: "right",
        trigger: "click",
        content: "",
        template: '<div class="popover" role="tooltip"><div class="arrow"><\/div><h3 class="popover-title"><\/h3><div class="popover-content"><\/div><\/div>'
    });
    t.prototype = n.extend({},
    n.fn.tooltip.Constructor.prototype);
    t.prototype.constructor = t;
    t.prototype.getDefaults = function() {
        return t.DEFAULTS
    };
    t.prototype.setContent = function() {
        var n = this.tip(),
        i = this.getTitle(),
        t = this.getContent();
        n.find(".popover-title")[this.options.html ? "html": "text"](i);
        n.find(".popover-content").children().detach().end()[this.options.html ? "string" == typeof t ? "html": "append": "text"](t);
        n.removeClass("fade top bottom left right in");
        n.find(".popover-title").html() || n.find(".popover-title").hide()
    };
    t.prototype.hasContent = function() {
        return this.getTitle() || this.getContent()
    };
    t.prototype.getContent = function() {
        var t = this.$element,
        n = this.options;
        return t.attr("data-content") || ("function" == typeof n.content ? n.content.call(t[0]) : n.content)
    };
    t.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".arrow")
    };
    i = n.fn.popover;
    n.fn.popover = r;
    n.fn.popover.Constructor = t;
    n.fn.popover.noConflict = function() {
        return n.fn.popover = i,
        this
    }
} (jQuery); +
function(n) {
    "use strict";
    function t(i, r) {
        this.$body = n(document.body);
        this.$scrollElement = n(n(i).is(document.body) ? window: i);
        this.options = n.extend({},
        t.DEFAULTS, r);
        this.selector = (this.options.target || "") + " .nav li > a";
        this.offsets = [];
        this.targets = [];
        this.activeTarget = null;
        this.scrollHeight = 0;
        this.$scrollElement.on("scroll.bs.scrollspy", n.proxy(this.process, this));
        this.refresh();
        this.process()
    }
    function i(i) {
        return this.each(function() {
            var u = n(this),
            r = u.data("bs.scrollspy"),
            f = "object" == typeof i && i;
            r || u.data("bs.scrollspy", r = new t(this, f));
            "string" == typeof i && r[i]()
        })
    }
    t.VERSION = "3.3.7";
    t.DEFAULTS = {
        offset: 10
    };
    t.prototype.getScrollHeight = function() {
        return this.$scrollElement[0].scrollHeight || Math.max(this.$body[0].scrollHeight, document.documentElement.scrollHeight)
    };
    t.prototype.refresh = function() {
        var t = this,
        i = "offset",
        r = 0;
        this.offsets = [];
        this.targets = [];
        this.scrollHeight = this.getScrollHeight();
        n.isWindow(this.$scrollElement[0]) || (i = "position", r = this.$scrollElement.scrollTop());
        this.$body.find(this.selector).map(function() {
            var f = n(this),
            u = f.data("target") || f.attr("href"),
            t = /^#./.test(u) && n(u);
            return t && t.length && t.is(":visible") && [[t[i]().top + r, u]] || null
        }).sort(function(n, t) {
            return n[0] - t[0]
        }).each(function() {
            t.offsets.push(this[0]);
            t.targets.push(this[1])
        })
    };
    t.prototype.process = function() {
        var n, i = this.$scrollElement.scrollTop() + this.options.offset,
        f = this.getScrollHeight(),
        e = this.options.offset + f - this.$scrollElement.height(),
        t = this.offsets,
        r = this.targets,
        u = this.activeTarget;
        if (this.scrollHeight != f && this.refresh(), i >= e) return u != (n = r[r.length - 1]) && this.activate(n);
        if (u && i < t[0]) return this.activeTarget = null,
        this.clear();
        for (n = t.length; n--;) u != r[n] && i >= t[n] && (void 0 === t[n + 1] || i < t[n + 1]) && this.activate(r[n])
    };
    t.prototype.activate = function(t) {
        this.activeTarget = t;
        this.clear();
        var r = this.selector + '[data-target="' + t + '"],' + this.selector + '[href="' + t + '"]',
        i = n(r).parents("li").addClass("active");
        i.parent(".dropdown-menu").length && (i = i.closest("li.dropdown").addClass("active"));
        i.trigger("activate.bs.scrollspy")
    };
    t.prototype.clear = function() {
        n(this.selector).parentsUntil(this.options.target, ".active").removeClass("active")
    };
    var r = n.fn.scrollspy;
    n.fn.scrollspy = i;
    n.fn.scrollspy.Constructor = t;
    n.fn.scrollspy.noConflict = function() {
        return n.fn.scrollspy = r,
        this
    };
    n(window).on("load.bs.scrollspy.data-api",
    function() {
        n('[data-spy="scroll"]').each(function() {
            var t = n(this);
            i.call(t, t.data())
        })
    })
} (jQuery); +
function(n) {
    "use strict";
    function r(i) {
        return this.each(function() {
            var u = n(this),
            r = u.data("bs.tab");
            r || u.data("bs.tab", r = new t(this));
            "string" == typeof i && r[i]()
        })
    }
    var t = function(t) {
        this.element = n(t)
    },
    u,
    i;
    t.VERSION = "3.3.7";
    t.TRANSITION_DURATION = 150;
    t.prototype.show = function() {
        var t = this.element,
        f = t.closest("ul:not(.dropdown-menu)"),
        i = t.data("target"),
        u;
        if (i || (i = t.attr("href"), i = i && i.replace(/.*(?=#[^\s]*$)/, "")), !t.parent("li").hasClass("active")) {
            var r = f.find(".active:last a"),
            e = n.Event("hide.bs.tab", {
                relatedTarget: t[0]
            }),
            o = n.Event("show.bs.tab", {
                relatedTarget: r[0]
            }); (r.trigger(e), t.trigger(o), o.isDefaultPrevented() || e.isDefaultPrevented()) || (u = n(i), this.activate(t.closest("li"), f), this.activate(u, u.parent(),
            function() {
                r.trigger({
                    type: "hidden.bs.tab",
                    relatedTarget: t[0]
                });
                t.trigger({
                    type: "shown.bs.tab",
                    relatedTarget: r[0]
                })
            }))
        }
    };
    t.prototype.activate = function(i, r, u) {
        function e() {
            f.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !1);
            i.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded", !0);
            o ? (i[0].offsetWidth, i.addClass("in")) : i.removeClass("fade");
            i.parent(".dropdown-menu").length && i.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !0);
            u && u()
        }
        var f = r.find("> .active"),
        o = u && n.support.transition && (f.length && f.hasClass("fade") || !!r.find("> .fade").length);
        f.length && o ? f.one("bsTransitionEnd", e).emulateTransitionEnd(t.TRANSITION_DURATION) : e();
        f.removeClass("in")
    };
    u = n.fn.tab;
    n.fn.tab = r;
    n.fn.tab.Constructor = t;
    n.fn.tab.noConflict = function() {
        return n.fn.tab = u,
        this
    };
    i = function(t) {
        t.preventDefault();
        r.call(n(this), "show")
    };
    n(document).on("click.bs.tab.data-api", '[data-toggle="tab"]', i).on("click.bs.tab.data-api", '[data-toggle="pill"]', i)
} (jQuery); +
function(n) {
    "use strict";
    function i(i) {
        return this.each(function() {
            var u = n(this),
            r = u.data("bs.affix"),
            f = "object" == typeof i && i;
            r || u.data("bs.affix", r = new t(this, f));
            "string" == typeof i && r[i]()
        })
    }
    var t = function(i, r) {
        this.options = n.extend({},
        t.DEFAULTS, r);
        this.$target = n(this.options.target).on("scroll.bs.affix.data-api", n.proxy(this.checkPosition, this)).on("click.bs.affix.data-api", n.proxy(this.checkPositionWithEventLoop, this));
        this.$element = n(i);
        this.affixed = null;
        this.unpin = null;
        this.pinnedOffset = null;
        this.checkPosition()
    },
    r;
    t.VERSION = "3.3.7";
    t.RESET = "affix affix-top affix-bottom";
    t.DEFAULTS = {
        offset: 0,
        target: window
    };
    t.prototype.getState = function(n, t, i, r) {
        var u = this.$target.scrollTop(),
        f = this.$element.offset(),
        e = this.$target.height();
        if (null != i && "top" == this.affixed) return u < i && "top";
        if ("bottom" == this.affixed) return null != i ? !(u + this.unpin <= f.top) && "bottom": !(u + e <= n - r) && "bottom";
        var o = null == this.affixed,
        s = o ? u: f.top,
        h = o ? e: t;
        return null != i && u <= i ? "top": null != r && s + h >= n - r && "bottom"
    };
    t.prototype.getPinnedOffset = function() {
        if (this.pinnedOffset) return this.pinnedOffset;
        this.$element.removeClass(t.RESET).addClass("affix");
        var n = this.$target.scrollTop(),
        i = this.$element.offset();
        return this.pinnedOffset = i.top - n
    };
    t.prototype.checkPositionWithEventLoop = function() {
        setTimeout(n.proxy(this.checkPosition, this), 1)
    };
    t.prototype.checkPosition = function() {
        var i, e, o;
        if (this.$element.is(":visible")) {
            var s = this.$element.height(),
            r = this.options.offset,
            f = r.top,
            u = r.bottom,
            h = Math.max(n(document).height(), n(document.body).height());
            if ("object" != typeof r && (u = f = r), "function" == typeof f && (f = r.top(this.$element)), "function" == typeof u && (u = r.bottom(this.$element)), i = this.getState(h, s, f, u), this.affixed != i) {
                if (null != this.unpin && this.$element.css("top", ""), e = "affix" + (i ? "-" + i: ""), o = n.Event(e + ".bs.affix"), this.$element.trigger(o), o.isDefaultPrevented()) return;
                this.affixed = i;
                this.unpin = "bottom" == i ? this.getPinnedOffset() : null;
                this.$element.removeClass(t.RESET).addClass(e).trigger(e.replace("affix", "affixed") + ".bs.affix")
            }
            "bottom" == i && this.$element.offset({
                top: h - s - u
            })
        }
    };
    r = n.fn.affix;
    n.fn.affix = i;
    n.fn.affix.Constructor = t;
    n.fn.affix.noConflict = function() {
        return n.fn.affix = r,
        this
    };
    n(window).on("load",
    function() {
        n('[data-spy="affix"]').each(function() {
            var r = n(this),
            t = r.data();
            t.offset = t.offset || {};
            null != t.offsetBottom && (t.offset.bottom = t.offsetBottom);
            null != t.offsetTop && (t.offset.top = t.offsetTop);
            i.call(r, t)
        })
    })
} (jQuery);
String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, "")
};
sharedScripts = {};
sharedScripts.contentSearch = function(n) {
    n.length && (window.location = "?page=search&searchString=" + n)
};
sharedScripts.writeScript = function(n) {
    document.write('<script src="' + n + '" type="text/JavaScript"><\/script>')
};
sharedScripts.addScript = function(n) {
    var t = document.getElementsByTagName("head")[0];
    script = document.createElement("script");
    script.type = "text/javascript";
    script.src = n;
    t.appendChild(script)
};
sharedScripts.loadScript = function(n) {
    var t = window.XMLHttpRequest ? new XMLHttpRequest: new ActiveXObject("MSXML2.XMLHTTP.3.0"),
    i;
    t.open("GET", n, !1);
    t.send(null);
    i = document.getElementsByTagName("head")[0];
    script = document.createElement("script");
    script.type = "text/javascript";
    script.text = t.responseText;
    i.appendChild(script)
};
window.onload = function() {
    var n = document.getElementsByName("scrollx"),
    t = document.getElementsByName("scrolly"),
    i,
    r;
    n.length > 0 && t.length > 0 && (window.onscroll = function() {
        var i = document.body.scrollTop;
        i == 0 && (n[0].value = document.all ? document.body.parentElement.scrollLeft: window.pageXOffset, t[0].value = document.all ? document.body.parentElement.scrollTop: window.pageYOffset);
        window.status = n[0].value + "," + t[0].value
    });
    n.length > 0 && t.length > 0 && n[0].value + t[0].value > 0 ? (window.scrollTo(n[0].value, t[0].value), window.status = n[0].value + "," + t[0].value) : window.location.hash.length > 1 && window.location.hash.indexOf("=") < 1 && (i = $(window.location.hash).first(), r = window.location.hash.substr(1), i.length == 0 && (i = $("[name=" + r + "]").first()), i.length > 0 && (window.scrollTo(0, Math.max((i.offset() || {
        top: 1
    }).top - ($("header").outerHeight() || 0) - 10, 0)), setTimeout(function() {
        window.scrollTo(0, Math.max((i.offset() || {
            top: 1
        }).top - ($("header").outerHeight() || 0) - 10, 0))
    },
    250), window.mwdata && typeof mwdata.hashCallback == "function" && mwdata.hashCallback(r)))
};
contentRotator = function() {
    var n, t = 0;
    return {
        init: function(i, r) {
            var u = this;
            n = $(i);
            $(n[t]).siblings(i).each(function() {
                $(this).toggle(!1)
            });
            n.length > 1 && setInterval(function() {
                $(n[t++]).toggle(!1);
                t == n.length && (t = 0);
                $(n[t]).toggle(!0)
            },
            r)
        }
    }
} ();
definitions = function() {
    var n;
    return {
        init: function() {},
        show: function() {},
        hide: function() {
            n.css("left", "-10000px");
            n.toggle(!1);
            n.empty()
        },
        setPosition: function(t) {
            var i = t.offset().left,
            r = t.offset().top + t.height() + 5;
            i + n.width() > document.body.offsetWidth && (i = t.position().left + t.width() - n.width() - 20);
            n.css("z-index", "10000000");
            n.css("left", i + "px");
            n.css("top", r + "px")
        }
    }
} ();
$(function() {
    definitions.init()
});
var topicSelector = function() {
    var n = 0;
    return {
        init: function() {
            var r = $(".topic-selector"),
            t = $(".topic-selector li"),
            u = $(".topic-selector li img"),
            f = $(".topic-selector p"),
            i;
            window.location.hash.length > 2 && (i = new RegExp("^" + window.location.hash.substr(2), "i"), t.each(function(t, r) {
                i.test(r.innerHTML.toLowerCase().replace(/&([\w]{1,6};){0,1}/gi, "").replace(/[^\w\s\-]/gi, "").replace(/\s+/gi, "-")) && (n = t)
            }));
            t.each(function() {
                var t = $(this);
                t.hover(function() {
                    n != t.index() && (t.css("text-decoration", "underline"), t.css("cursor", "pointer"))
                },
                function() {
                    t.css("text-decoration", "none")
                });
                t.click(function() {
                    n = t.index();
                    var e = t.siblings("li"),
                    i = $(f[n]);
                    r.css("background-image", "url('" + $(u[n]).attr("src") + "')");
                    i.toggle(!0);
                    i.siblings("p").toggle(!1);
                    t.attr("class", "topic-selected");
                    t.css("text-decoration", "none");
                    e.attr("class", "")
                })
            });
            $(t[n]).click().toggle(t.length > 1)
        }
    }
} (),
linkButtons = function() {
    return {
        init: function(n) {
            $(n).each(function() {
                var n = $(this),
                t = n.find("a");
                t.length != 0 && (n.css("cursor", "pointer"), n.click(function() {
                    window.location = $(t[0]).attr("href")
                }))
            })
        }
    }
} (),
rankRadio = function() {
    function t(t) {
        for (i = 0; i < n.length; i++) i <= t ? $(n[i]).addClass("on") : $(n[i]).removeClass("on")
    }
    var n;
    return {
        init: function(i) {
            var r = $(i);
            n = r.find("label");
            r.find("input").each(function(n) {
                var i = $(this);
                i.is(":checked") ? t(n) : !0;
                i.click(function() {
                    t(n)
                })
            });
            r.addClass("rankRadio")
        }
    }
} (),
reviews = function() {
    var n;
    return {
        init: function() {
            if (!n) {
                n = this;
                var t = !$.reviews.product & $.reviews.product.length == 0;
                t && $.post($.reviews.productsUrl, {
                    src: $.reviews.source
                },
                function(t) {
                    if (t != "error" && t != "exception") {
                        var i = $("#product-list-template").html(),
                        r = Handlebars.compile(i),
                        t = {
                            name: "",
                            products: t
                        };
                        $($.reviews.productsSelect).html(r(t));
                        $($.reviews.productsSelect + ">select").change(function() {
                            this.selectedIndex == 0 ? n.buildPager() : n.buildPager($(this).val())
                        })
                    } else $($.reviews.productsSelect).html("")
                });
                n.buildPager($.reviews.product)
            }
        },
        buildPager: function(t) {
            t = t ? unescape(t) : unescape($.reviews.product);
            $.post($.reviews.reviewsUrl, {
                src: $.reviews.source,
                product: t,
                page: 1,
                pagesize: $.reviews.pagesize,
                pagecount: 1
            },
            function(r) {
                if (r != "error" && r != "exception") {
                    var f = $("#product-review-pager-template").html(),
                    e = Handlebars.compile(f),
                    u = [];
                    for (i = 1; i <= parseInt(r); i++) u.push({
                        page: i
                    });
                    $($.reviews.reviewsContainer + "-pager").html(e({
                        name: "",
                        pages: u
                    }));
                    $($.reviews.reviewsContainer + "-pager>a").click(function() {
                        var i = $(this);
                        return n.search(t, parseInt(i.text())),
                        $($.reviews.reviewsContainer + "-pager>a").removeClass("selected"),
                        i.addClass("selected"),
                        !1
                    });
                    $($($.reviews.reviewsContainer + "-pager>a")[0]).click()
                } else $($.reviews.reviewsContainer + "-content").html(""),
                $($.reviews.reviewsContainer).toggle(!1)
            })
        },
        search: function(n, t) {
            n = n ? unescape(n) : unescape($.reviews.product);
            t = t ? t: 1;
            $.post($.reviews.reviewsUrl, {
                src: $.reviews.source,
                product: n,
                page: t,
                pagesize: $.reviews.pagesize
            },
            function(n) {
                if (n != "error" && n != "exception") {
                    var t = $("#product-review-template").html(),
                    i = Handlebars.compile(t),
                    n = {
                        name: "",
                        reviews: n
                    };
                    $($.reviews.reviewsContainer + "-content").html(i(n));
                    $($.reviews.reviewsContainer).toggle(!0)
                } else $($.reviews.reviewsContainer + "-content").html(""),
                $($.reviews.reviewsContainer).toggle(!1)
            })
        }
    }
} (),
framer = function(n, t, i, r, u) {
    var f = this;
    r = r ? r: "100%";
    i = i ? i: 200;
    u = u ? u: "no";
    f.c = $("<div><\/div>");
    f.c.addClass("framer");
    f.c.appendTo($(n));
    t += t.indexOf("?") != -1 ? "&frame=1": "?frame=1";
    f.f = $('<iframe src="' + t + '" frameborder="0" scrolling="' + u + '"><\/iframe>');
    f.f.on("load",
    function() {
        var n, t;
        try {
            n = this.contentWindow.document.body.offsetHeight
        } catch(u) {}
        t = n ? n + 50 : i;
        f.f.height(t);
        f.f.width(r);
        f.c.height(t);
        f.c.width(r)
    });
    f.c.show = function() {
        f.shown ? f.shown: f.f.appendTo(f.c);
        f.shown = !0
    };
    f.show = function() {
        f.c.show()
    }
};
document.createElement("header");
document.createElement("nav");
document.createElement("main");
document.createElement("footer"),
function() {
    "use strict";
    var n = {};
    n.parse = function(n) {
        return typeof n != "string" ? {}: (n = n.trim().replace(/^\?/, ""), !n) ? {}: n.trim().split("&").reduce(function(n, t) {
            var u = t.replace(/\+/g, " ").split("="),
            i = u[0],
            r = u[1];
            return i = decodeURIComponent(i),
            r = r === undefined ? null: decodeURIComponent(r),
            n.hasOwnProperty(i) ? Array.isArray(n[i]) ? n[i].push(r) : n[i] = [n[i], r] : n[i] = r,
            n
        },
        {})
    };
    n.stringify = function(n) {
        return n ? Object.keys(n).map(function(t) {
            var i = n[t];
            return Array.isArray(i) ? i.map(function(n) {
                return encodeURIComponent(t) + "=" + encodeURIComponent(n)
            }).join("&") : encodeURIComponent(t) + "=" + i
        }).join("&") : ""
    };
    n.push = function(t, i) {
        var r = n.parse(location.search);
        r[t] = i;
        history.replaceState({},
        "", window.location.pathname + "?" + n.stringify(r))
    };
    typeof module != "undefined" && module.exports ? module.exports = n: window.queryString = n
} ();
piAId = "125691";
piCId = "1683",

$(function() {
    function tt(n, t) {
        var i = 0,
        r;
        return (typeof i != "number" || !isFinite(i) || Math.floor(i) !== i || i > n.length) && (i = n.length),
        i -= t.length,
        r = n.indexOf(t, i),
        r !== -1 && r === i
    }
    function s() {
        var t = "",
        n;
        try {
            t = Cookies.get("brands")
        } catch(i) {}
        $("html").removeAttr("class");
        switch (t) {
        case "1":
        case "marvin":
            $("html").addClass("infinity-off integrity-off");
            $(".brand-switch input[value=marvin]").prop("checked", !0).parents(".brand-switch").siblings(".brand-switch").find("input").prop("checked", !1);
            break;
        case "2":
        case "integrity":
            $("html").addClass("infinity-off marvin-off");
            $(".brand-switch input[value=integrity]").prop("checked", !0).parents(".brand-switch").siblings(".brand-switch").find("input").prop("checked", !1);
            break;
        case "4":
        case "infinity":
            $("html").addClass("integrity-off marvin-off");
            $(".brand-switch input[value=infinity]").prop("checked", !0).parents(".brand-switch").siblings(".brand-switch").find("input").prop("checked", !1);
            break;
        case "3":
        case "marvin,integrity":
            $("html").addClass("infinity-off");
            $(".brand-switch input[value=infinity]").prop("checked", !1).parents(".brand-switch").siblings(".brand-switch").find("input").prop("checked", !0);
            break;
        case "5":
        case "marvin,infinity":
            $("html").addClass("integrity-off");
            $(".brand-switch input[value=integrity]").prop("checked", !1).parents(".brand-switch").siblings(".brand-switch").find("input").prop("checked", !0);
            break;
        case "6":
        case "integrity,infinity":
            $("html").addClass("marvin-off");
            $(".brand-switch input[value=marvin]").prop("checked", !1).parents(".brand-switch").siblings(".brand-switch").find("input").prop("checked", !0);
            break;
        case "7":
        case "marvin,integrity,infinity":
            $(".brand-switch input").prop("checked", !0)
        }
        n = "";
        try {
            n = Cookies.get("segment")
        } catch(i) {}
        switch (n) {
        case "2":
        case "commercial":
            $(".project-settings input[value=commercial]").prop("checked", !0);
            break;
        default:
            $(".project-settings input[value=residential]").prop("checked", !0)
        }
    }
    function it() {
        pageWidth > 320 && $(".mobi-submenu").css("left", pageWidth + "px")
    }
    function rt() {
        $(".mobi-nav li").removeClass("active");
        $(".mobi-nav li").parent().parent().parent().removeClass("open");
        $(".mobi-submenu").removeAttr("style");
        $("#tablet-drop-menu").removeAttr("style");
        $("#tablet-drop-menu > div").removeAttr("style");
        it()
    }
    function w(t) {
        u = 1;
        t == "r" || o < i && t == undefined ? ($("#mega-" + n).css({
            left: pageWidth + "px",
            opacity: "1"
        }), $("#mega-" + r).animate({
            left: "-" + pageWidth + "px"
        },
        1e3, "easeOutQuart"), $("#mega-" + n).animate({
            left: "0"
        },
        1e3, "easeOutQuart",
        function() {
            b()
        })) : (t == "l" || o > i && t == undefined) && ($("#mega-" + n).css({
            left: "-" + pageWidth + "px",
            opacity: "1"
        }), $("#mega-" + r).animate({
            left: pageWidth + "px"
        },
        1e3, "easeOutQuart"), $("#mega-" + n).animate({
            left: "0"
        },
        1e3, "easeOutQuart",
        function() {
            b()
        }))
    }
    function b() {
        $("#mega-" + r).removeClass("currMega");
        $("#mega-" + n).addClass("currMega");
        r = n;
        o = i;
        n = "";
        u = 0;
        $(".mega-nav-single").each(function() {
            var n = $(this);
            n.hasClass("currMega") || n.css("left", "-9999px")
        })
    }
    function ut() {
        $(".filter-check li label").each(function() {
            var n = $(this);
            $(this).children("input").attr("checked") && $(this).parent().attr("data-state", "on")
        })
    }
    function y() {
        pageWidth >= 750 ? ($(".center-height").each(function() {
            var n = $(this),
            t = n.height(),
            i = n.parent().height(),
            r = i / 2 - t / 2;
            n.css("padding-top", r + "px")
        }), $(".center-width").each(function() {
            var n = $(this),
            t = n.width(),
            i = n.parent().width(),
            r = i / 2 - t / 2;
            n.css("margin-left", r + "px")
        })) : $(".center-height").removeAttr("style");
        $(".promo-copy").each(function() {
            var n = $(this),
            t = n.height(),
            i = n.parent().height(),
            r = i / 2 - t / 2 - 6;
            n.css("padding-top", r + "px")
        })
    }
    try {
        Cookies.remove("design")
    } catch(ft) {}
    mwdata.rewrites == null && (mwdata.rewrites = $("#top-nav-bar .tnb-txt").attr("href") === "/");
    $(".drop-nav-dealer button,#mega-dealer button,.drop-nav-search button,#mega-search button,.gallery-search button,.tnb-signin button").click(function() {
        $(this).siblings("input").trigger($.Event("keydown", {
            keyCode: 13
        }))
    });
    $("input#dn-find-dealer,input#ih-find-dealer,input#dn-search,input#ih-search,input#insp-find-dealer,input#head-search,input#mobile-head-search").keydown(function(n) {
        var i, t; (n.keyCode == 13 || n.which == 13) && (n.preventDefault(), n.target.name == "find-dealer" ? (i = /^(?:marvin|integrity|infinity)/.exec(mwdata.page), location.href = window.location.href.indexOf("support.marvin") > -1 ? "https://www.marvin.com/where-to-buy?search=" + encodeURIComponent(n.target.value) + (i ? "&brands=" + i[0] : "") : location.protocol + "//" + location.host + "/" + (mwdata.rewrites ? "where-to-buy?": "?page=where-to-buy&") + "search=" + encodeURIComponent(n.target.value) + (i ? "&brands=" + i[0] : "")) : (t = "", t = replaceAll(encodeURIComponent(cleanSearchTerm(n.target.value)), "%2540", "%40"), t.endsWith("%20") && (t = t.substr(0, t.length - 3)), location.href = "" + t))
    });
    $("textarea#searchAskInput").keydown(function(n) {
        if (n.keyCode == 13 || n.which == 13) {
            n.preventDefault();
            var t = "";
            t = n.target.value;
            t = replaceAll(encodeURIComponent(cleanSearchTerm(t)), "%2540", "%40");
            tt(t, "%20") && (t = t.substr(0, t.length - 3));
            location.href = "http://support.marvin.com/knowledge_display_Home?l=en_US&q=" + t
        }
    });
    $("html").removeClass("no-js");
    pageWidth = $(window).innerWidth();
    pageHeight = $(window).height();
    $window = $(window);
    isIE = $("html").hasClass("isie");
    y();
    var p, r, n, o, i, u = 0,
    t = [],
    c = [];
    s();
    $("a.btn-international").on("click",
    function(n) {
        n.preventDefault();
        var t = $(this);
        try {
            Cookies.set("brands", "3")
        } catch(n) {}
        s();
        t.hide();
        $(".btn-usa").show();
        window.document.location.href = $(this).attr("href")
    });
    $("li.btn-international").on("click",
    function(n) {
        n.preventDefault();
        var t = $(this);
        try {
            Cookies.set("brands", "3")
        } catch(n) {}
        s();
        t.hide();
        $(".btn-usa").show();
        window.document.location.href = $(this).children("a:first").attr("href")
    });
    $(".btn-usa").on("click",
    function(n) {
        n.preventDefault();
        var t = $(this);
        try {
            Cookies.set("brands", "7")
        } catch(n) {}
        s();
        t.hide();
        $(".btn-international").show()
    });
    $(".mega-nav").on("click",
    function(f) {
        var e, s;
        f.preventDefault();
        e = $(this);
        $("body").addClass("mega-open");
        $(".nav-set ul li").each(function() {
            var n = $(this).attr("data-nav");
            n != "settings" && $(this).is(":visible") && !$(this).hasClass("mega-nav-link") && t.push(n)
        });
        $(this).hasClass("active") || $(".mega-nav-container").hasClass("open") || u != 0 || $(this).hasClass("mega-nav-link") ? $(this).hasClass("active") || !$(".mega-nav-container").hasClass("open") || u != 0 || $(this).hasClass("mega-nav-link") ? $(this).hasClass("active") ? $(".mega-nav-close").trigger("click") : $(this).hasClass("mega-nav-link") && ($(".mega-nav-close").trigger("click"), s = e.children("a").attr("href"), window.location.replace(s)) : (i = $(this).parent().children().index(this), n = e.attr("data-nav"), r = $(".mega-nav.active").attr("data-nav"), $("nav li").removeClass("active"), e.removeAttr("style").addClass("active"), w()) : (o = $(this).parent().children().index(this), p = e.attr("data-nav"), $("#mega-" + p).addClass("currMega"), $("nav li").removeClass("active"), $(".mega-nav-container").addClass("open"), e.removeAttr("style").addClass("active"), $(".container-content-cover").show(), $(".mega-nav-close, .mega-nav-arrow-right, .mega-nav-arrow-left").show(0,
        function() {
            $("body").css("overflow", "hidden")
        }))
    });
    $(".mega-nav-close").on("click",
    function() {
        t = [];
        $("body").removeClass("mega-open");
        $("nav li").removeClass("active");
        $(".mega-nav-container").removeClass("open");
        $(".mega-nav-single").removeClass("currMega");
        $(".mega-nav-close, .mega-nav-arrow-right, .mega-nav-arrow-left").hide(function() {
            $(".mega-nav-single").removeAttr("style");
            $("body").removeAttr("style")
        });
        $("body").hasClass("settings-open") || $(".container-content-cover").hide()
    });
    $(".container-content-cover").on("click",
    function() {
        t = [];
        $("body").removeClass("mega-open");
        $("nav li").removeClass("active");
        $(".mega-nav-container").removeClass("open");
        $(".mega-nav-single").removeClass("currMega");
        $(".mega-nav-close, .mega-nav-arrow-right, .mega-nav-arrow-left").hide(function() {
            $(".mega-nav-single").removeAttr("style");
            $("body").removeAttr("style")
        });
        $("body").hasClass("settings-open") || $(".container-content-cover").hide()
    });
    $(".mega-arrow").on("click",
    function() {
        var c;
        if (u == 0) {
            c = $(this);
            r = $(".mega-nav.active").attr("data-nav");
            var e = c.attr("data-direction"),
            f = t.indexOf(r),
            h = t.length - 1,
            o = $("#main-nav ul li"),
            s;
            e == "l" && f != 0 ? (s = f - 1, n = t[s], i = o.index($('li[data-nav="' + n + '"]'))) : e == "l" && f == 0 ? (n = t[h], i = o.index($('li[data-nav="' + n + '"]'))) : e == "r" && f != h ? (s = f + 1, n = t[s], i = o.index($('li[data-nav="' + n + '"]'))) : e == "r" && f == h && (n = t[0], i = o.index($('li[data-nav="' + n + '"]')));
            $("nav li").removeClass("active");
            $('nav li[data-nav="' + n + '"]').removeAttr("style").addClass("active");
            w(e)
        }
    });
    $(".nav-settings").on("click",
    function() {
        $(this).blur();
        $(".container-all").css("width", pageWidth + "px");
        $(".container-settings").css("height", pageHeight + "px");
        $("body").addClass("settings-open");
        $(".container-header-cover, .container-content-cover").show();
        $(".container-settings").animate({
            left: "0"
        },
        250);
        $(".container-all, header").animate({
            left: "350px"
        },
        250);
        $(".mega-nav-close").trigger("click")
    });
    $(".container-header-cover, .container-content-cover").click(function() {
        $("body").hasClass("settings-open") && ($("body").removeClass("settings-open"), $(".container-header-cover, .container-content-cover").hide(), $(".container-settings").animate({
            left: "-350px"
        },
        250), $(".container-all, header").animate({
            left: "0"
        },
        250,
        function() {
            $(this).removeAttr("style")
        }), window.document.location.reload())
    });
    $(".container-header-cover, .container-content-cover").hover(function() {
        $("li.nav-settings").html("Close").addClass("setClose")
    },
    function() {
        $("li.nav-settings").html("Settings").removeClass("setClose")
    });
    $(".trade-set").on("click",
    function() {
        var n = $(this),
        t = n.attr("data-userType");
        $(".trade-set").removeClass("on").attr("data-selected", "off");
        n.addClass("on").attr("data-selected", "on");
        t == "residential" && $(".trade-sub-set").removeClass("on").attr("data-selected", "off")
    });
    $(".trade-sub-set").click(function() {
        var n = $(this),
        t = n.attr("data-userType");
        $(".trade-sub-set").removeClass("on").attr("data-selected", "off");
        n.addClass("on").attr("data-selected", "on")
    });
    $(".project-settings input").change(function() {
        if (this.value == "commercial" && this.checked == !0) {
            $(".project-settings input[value=commercial]").prop("checked", !0);
            try {
                Cookies.set("segment", 2)
            } catch(e) {}
        } else {
            $(".project-settings input[value=residential]").prop("checked", !0);
            try {
                Cookies.set("segment", 1)
            } catch(e) {}
        }
    });
    $("#mega-menu .brand-hero-image,.promo-item-holder").click(function(n) {
        if (n.target.nodeName != "A" && $(n.target).parents("a").length == 0) {
            var t = $(this).find("a[href]");
            t.length > 0 && t[0].click()
        }
    });
    $(".mobi-nav li").on("tap click",
    function(n) {
        var r;
        n.stopPropagation();
        n.preventDefault();
        var i = $(this),
        t = i.attr("data-nav"),
        u = $(".drop-nav-" + t);
        t == "close" || i.hasClass("active") ? (rt(), u.removeClass("mobileWTB")) : (t != "dealer" && ($(".mobi-nav li").removeClass("active"), r = $(".drop-nav-" + t).height(), i.addClass("active"), i.parent().parent().parent().addClass("open"), $("#tablet-drop-menu").css("height", r + "px"), $("#tablet-drop-menu > div").removeAttr("style"), $(".drop-nav-" + t).css({
            "z-index": "100",
            opacity: "1"
        })), t == "dealer" && (window.location = "/?page=where-to-buy"))
    });
    $("li.has-sub").on("tap click",
    function(n) {
        var f;
        if (n.stopPropagation(), n.target.nodeName != "A" && !($(n.target).parents(".settings-main").length > 0)) {
            n.preventDefault();
            var t, i = $(this),
            e = i.attr("data-nav"),
            r = i.children("ul"),
            u = i.children("ul").height();
            t = pageWidth > 320 ? pageWidth: 320;
            e == "professionals" ? (f = i.children().children().children("ul"), $("#tablet-drop-menu").css("height", u + "px"), r.css({
                left: t + "px",
                display: "block",
                opacity: 1,
                "z-index": 50
            }), f.css({
                left: t * 2 + "px"
            }), $(".drop-nav-all").css("left", "-" + t + "px")) : ($("#tablet-drop-menu").css("height", u + "px"), r.css({
                left: t + "px",
                display: "block",
                opacity: 1,
                "z-index": 50
            }), $(".drop-nav-all").css("left", "-" + t + "px"));
            $("html, body").animate({
                scrollTop: $("#tablet-drop-menu").offset().top
            },
            500)
        }
    });
    $("li.has-sub-2").on("tap click",
    function(n) {
        if (n.stopPropagation(), n.target.nodeName != "A" && !($(n.target).parents(".settings-main").length > 0)) {
            n.preventDefault();
            var t, i = $(this),
            f = i.attr("data-nav"),
            r = i.children("ul"),
            u = i.children("ul").height();
            t = pageWidth > 320 ? pageWidth: 320;
            $("#tablet-drop-menu").css("height", u + "px");
            $(".drop-nav-all").css("left", "-" + t * 2 + "px");
            $(".mobi-submenu").css("left", t + "px");
            r.css({
                left: t + "px",
                display: "block",
                opacity: 1,
                "z-index": 50
            });
            $("html, body").animate({
                scrollTop: $("#tablet-drop-menu").offset().top
            },
            500)
        }
    });
    $("li.mobi-sub-back").on("tap click",
    function(n) {
        n.stopPropagation();
        n.preventDefault();
        var t = $(this),
        i = t.parent().parent().parent().height();
        $("#tablet-drop-menu").css("height", i + "px");
        $(".drop-nav-all").css("left", "0");
        t.parent().css({
            "z-index": 0
        });
        $("html, body").animate({
            scrollTop: $("header").offset().top
        },
        500)
    });
    $("li.mobi-sub-back-2").on("tap click",
    function(n) {
        n.stopPropagation();
        n.preventDefault();
        var t = $(this),
        i = t.parent().parent().parent().height();
        $("#tablet-drop-menu").css("height", i + "px");
        $(".drop-nav-all").css("left", "-" + pageWidth + "px");
        $(".mobi-submenu").css("left", pageWidth + "px");
        t.parent().css({
            "z-index": 0
        })
    });
    $(".brand-switch input").on("tap click",
    function() {
        var t, n;
        c = [];
        t = "";
        try {
            t = Cookies.get("brands")
        } catch(e) {}
        this.checked || $(this).parents(".settings-main").find(".brand-switch input:checked").length != 0 ? ($("html").toggleClass(this.value + "-off"), $(".brand-switch input[value=" + this.value + "]").prop("checked", this.checked)) : (this.checked = !0, alert("You Cannot Turn Off All Brands"));
        removeBrandFromQueryString("marvin");
        removeBrandFromQueryString("integrity");
        removeBrandFromQueryString("infinity");
        n = 0;
        $(".brand-switch input:checked").each(function() {
            var t = this.value;
            this.checked && c.indexOf(t) == -1 && (c.push(t), t == "marvin" && (n += 1, addBrandToQueryString("marvin")), t == "integrity" && (n += 2, addBrandToQueryString("integrity")), t == "infinity" && (n += 4, addBrandToQueryString("infinity")))
        });
        try {
            Cookies.set("brands", n.toString())
        } catch(e) {}
    });
    $(".btn-default.disabled").click(function(n) {
        n.preventDefault()
    });
    $(".plan-drop-holder .mv-drop-list").click(function() {
        var n = $("#plan-project-role").attr("data-value"),
        t = $("#plan-project-type").attr("data-value");
        t != "" && n != "" && $("#btn-plan-project").removeClass("disabled").html("Continue Planning")
    });
    $(".mv-drop-down").click(function() {
        var n = $(this),
        u = n.attr("id"),
        r = n.position(),
        f = r.top - 10,
        e = r.left - 10,
        t = $('.mv-drop-list[data-listfor="' + u + '"]'),
        i = n.width();
        i = i + 20;
        n.hasClass("use-offset") && t.css({
            width: i + "px",
            top: f + "px",
            left: e + "px"
        });
        t.hasClass("mv-drop-list-below") && t.css({
            width: i + 1 + "px",
            "margin-top": "-1px"
        });
        n.parent().addClass("drop-open");
        t.removeClass("hidden")
    });
    $(".mv-drop-list li").click(function() {
        var n = $(this),
        r = n.html(),
        i = r.replace(/ |\//g, "-"),
        t;
        i = i.toLowerCase();
        t = n.parent().attr("data-listfor");
        $('ul[data-listfor="' + t + '"] li').removeClass("active");
        n.addClass("active");
        $("#" + t).html(r);
        $("#" + t).attr("data-value", i);
        n.parent().addClass("hidden")
    });
    $(document).on("mouseleave", ".drop-open",
    function() {
        $(this).children(".mv-drop-list").addClass("hidden")
    });
    $(".has-child-list .mv-drop-list li").click(function() {
        var n = $(this),
        i = n.text(),
        r = n.parents(".has-child-list").attr("data-filterType"),
        t = $('[data-parentList="' + r + '"]');
        i != "All" ? t.show() : t.hide()
    });
    $("#newsletter-email").keyup(function() {
        $(".news-choice-holder").removeClass("hidden");
        $(".btn-news-go").css("display", "block")
    });
    $(".newsletter-choice").click(function() {
        var n = $(this),
        t = n.attr("data-selected");
        n.toggleClass("on");
        n.hasClass("on") ? n.attr("data-selected", "on") : n.attr("data-selected", "off")
    });
    $(".social-links li").click(function() {
        var t = $(this).attr("class");
        $(".social-links li").removeClass("active");
        var n = $(this),
        i = n.position(),
        r = i.left - 50;
        n.addClass("active");
        $(".social-link-choices").css("left", r + "px").removeClass("hidden").attr("data-social", t);
        $(".social-link-choice").removeClass("hidden");
        n.attr("data-urlinfinity") == "#" && $(".social-link-choice:contains('Infinity')").addClass("hidden");
        n.attr("data-urlintegrity") == "#" && $(".social-link-choice:contains('Integrity')").addClass("hidden");
        n.attr("data-urlmarvin") == "#" && $(".social-link-choice:contains('Marvin')").addClass("hidden")
    });
    $("footer").mouseleave(function() {
        $(".social-links li").removeClass("active");
        $(".social-link-choices, .news-choice-holder").addClass("hidden")
    });
    $(".ft-dwl-app, .ft-rqst-info").click(function() {
        var n = $(this).children().children().children("a").attr("href");
        window.location.href = n
    });
    $(".social-link-choice").click(function() {
        var n = $(this),
        t = n.html().toLowerCase(),
        i = n.parent().attr("data-social"),
        r = $("." + i).attr("data-url" + t);
        window.open(r, "_blank")
    });
    var h = $(".mega-nav").not(mwdata.page.indexOf("marvin") == 0 ? ".nav-marvin": "#jiberish").css("background-color"),
    f,
    e,
    l,
    k,
    d,
    g,
    nt,
    a = "rgba(255,255,255,0.75)",
    v = 75;
    $("li.spot-nav").mousemove(function(n) {
        $(this).hasClass("active") || ($tNav = $(this).offset(), f = n.pageX - $tNav.left, e = n.pageY - $tNav.top + 15, l = f + " " + e, nt = "radial-gradient(circle " + v + "px at " + f + "px " + e + "px, " + a + " 0%, " + h + ")", k = "-webkit-gradient(radial, " + l + ", 0, " + l + ", 100, from(rgba(255,255,255,0.8)), to(rgba(255,255,255,0.0))), " + h, d = "-moz-radial-gradient(" + f + "px " + e + "px 45deg, circle, " + a + " 0%, " + h + " " + v + "px)", g = "-ms-radial-gradient(" + f + "px " + e + "px 45deg, circle, " + a + " 0%, " + h + " " + v + "px)", $(this).css({
            background: nt
        }).css({
            background: k
        }).css({
            background: d
        }).css({
            background: g
        }))
    }).mouseleave(function() {
        $(this).removeAttr("style")
    });
    $("body").on("click", ".filter-circs li",
    function() {
        var n = $(this),
        t = n.attr("data-filter"),
        i = n.attr("data-state");
        n.siblings().attr("data-state", "off");
        n.parent().parent().attr("data-selected", t);
        n.attr("data-state", "on")
    });
    ut();
    $(".check-all-box").click(function() {
        var n = $(this),
        t = n.attr("data-state");
        t == "on" ? (n.attr("data-state", "off"), n.siblings("ul").children("li").attr("data-state", "off"), n.siblings("ul").children("li:first-child").attr("data-state", "on")) : (n.attr("data-state", "on"), n.siblings("ul").children("li").attr("data-state", "on"))
    });
    $(".plus-btn").each(function() {
        var n = $(this),
        t = n.parent().attr("data-filterType");
        n.find("img").click(function() {
            n.toggleClass("active");
            n.siblings("ul").toggle()
        })
    });
    $(window).resize(function() {
        y();
        pageWidth = $(window).innerWidth();
        pageHeight = $(window).height();
        pageWidth < 768 && ($("body").removeClass("mega-open"), $("body").removeAttr("style"), $(".container-content-cover").removeAttr("style"), $(".mega-nav-container").removeClass("open"), $(".mega-nav").removeClass("active"))
    });
    wrapYouTubePH();
    $(document).on("click", "img.ytvidPH",
    function() {
        var n = $(this),
        t = n.data("youtubeid") || "";
        n.parent().hasClass("embed-container") || n.wrap('<div class="embed-container"><\/div>');
        n.next(".ytvidLogo").length || n.after('<img class="ytvidLogo" src="/images/logo/social/YouTubePlay.png"/>');
        t ? n.before('<iframe class="ytvidF" frameborder="0" style="width:100%;min-height:50px" allowfullscreen src="https://www.youtube.com/embed/' + t + '?rel=0&autoplay=1&enablejsapi=1"><\/iframe>') : n.off("click")
    });
    $(document).on("click", ".ytvidPH+.ytvidLogo",
    function() {
        $(this).prev(".ytvidPH").click()
    });
    $(".content-block-arrow,.top-menu-item,.thumbnails img").click(function() {
        $("iframe.ytvidF").remove()
    });
    $(".rec-promo-single,.pprec-container").click(function() {
        var n = $(this),
        t = n.children().children("a").attr("href"),
        i = n.children().children("a").attr("target");
        i == "_blank" ? window.open(t, i) : window.location.href = t
    });
    y()
});
$(window).on("load",
function() {
    centerItem()
})