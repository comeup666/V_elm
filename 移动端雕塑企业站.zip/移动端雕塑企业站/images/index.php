<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<title>曲阳杰达雕塑有限公司</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<base target="_blank" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript">	
		function browserRedirect() {  
            var sUserAgent = navigator.userAgent.toLowerCase();  
            // console.info(sUserAgent)
            var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";  
            var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";  
            var bIsMidp = sUserAgent.match(/midp/i) == "midp";  
            var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";  
            var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";  
            var bIsAndroid = sUserAgent.match(/android/i) == "android";  
            var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";  
            var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";  
            if (bIsIpad || bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {  
               window.location.href = "http://www.jiedadiaosu.cn/m/index.html";
            }  
        }  
        browserRedirect(); 
	</script>

</head>
<body>
	<div class="main">
		<!-- 头部 -->
		<div class="top">
			<div class="top-left">
				<a href="">
					<img src="images/logo.png">
				</a>
			</div>
			<div class="top-right">
				<div class="contact-img">
					<img src="images/contact.jpg">
				</div>
				<div class="top-contact">
					<p class="contact-service">服务热线</p>
					<p class="contact-phone">156 3085 6998</p>
				</div>
			</div>
		</div>
		<!-- menu菜单部分 -->
		<div class="menu">
			<ul class="nav">
				<li>
					<a href="index.html">杰达首页</a>
				</li>
				<li>
					<a href="products.html">产品中心</a>
					<ul class="sub">
						<li>
							<a href="frp.html">玻璃钢</a>
						</li>
						<li>
							<a href="stainless.html">不锈钢</a>
						</li>
						<li>
							<a href="duantong.html">段铜</a>
						</li>
						<li>
							<a href="clay.html">泥塑</a>
						</li>
						<li>
							<a href="foam.html">泡沫雕塑</a>
						</li>
						<li>
							<a href="carving.html">石雕</a>
						</li>
						<li>
							<a href="cement.html">水泥雕塑</a>
						</li>
						<li>
							<a href="copper.html">铜雕</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="cases.html">工程案例</a>
				</li>
				<li>
					<a href="about.html">关于杰达</a>
				</li>
				<li>
					<a href="contact.html">联系我们</a>
				</li>
				<li class="nav-last">
					<a href="join.html">人才招聘</a>
				</li>
			</ul>
		</div>
		<!-- banner部分 -->
		<div class="banner">
			<ul class="banner-img">
				<li>
					<a href="clay.html">
						<img src="images/banner-01.jpg">
					</a>
				</li>
				<li>
					<a href="clay.html">
						<img src="images/banner-02.jpg">
					</a>
				</li>
				<li>
					<a href="cement.html">
						<img src="images/banner-03.jpg">
					</a>
				</li>
			</ul>
			<ul class="circle">
				<li class="active"></li>
				<li></li>
				<li></li>
			</ul>
		</div>

		<!-- 公司简介 -->
		<div class="introduce">
			<div class="intro-top">
				<h1>关于我们</h1>
				<p>曲阳杰达雕塑有限公司，欢迎您的到来！</p>	
			</div>
			<div class="intro-left">				
				<img src="images/company.jpg">
			</div>
			<div class="intro-right">
				<p>
					曲阳杰达雕塑有限公司是一家集玻璃钢浮雕雕塑,人造砂岩雕塑、城市雕塑、环境雕塑、园林景观、假山、浮雕壁画、砂岩的设计、制作、安装为一体的专业雕塑公司。主要承接大中小型不锈钢雕塑、青铜雕塑、玻璃钢仿铜雕塑、园林景观及各种装饰浮雕、壁画的设计和施工。
				</p>
				<p>
					公司位于中国陶瓷之都--山东淄博。公司拥有一批中央美院雕塑系及园林设计系师生的专业人员，艺术与技术相结合,且经验丰富；自成立以来一直致力于研制艺术砂岩、玻璃钢制品制作的新工艺、新材料，其设计以原创为本，追求经典艺术和现代生活的完美结合。
				</p>
				<p>
					公司秉承“以雕塑为主，以艺术为根”的发展理念,经过多年的磨砺,已成为淄博雕塑业的名牌企业,其作品广泛分布于市政广场、地产楼盘及酒店、桑拿、会所等。公司凭借自身的专业设计施工能力和专业的服务品质,为客户量身定做,赢得了客户的高度评价和社会的广泛赞誉。
				</p>
			</div>
		</div>

		
		<!-- 工程案例 -->
		<div class="case">
			<div class="case-title">
				<h2>
					<img src="images/case/case-title-01.png">
				</h2>
				<h2>
					<img src="images/case/case-title-02.png">
				</h2>
			</div>
			<div class="case-more">
				<a href="cases.html">
					<span>更多案例</span>
				</a>
			</div>
			<div class="wraper">
				<ul>
					<li>
						<a href="case01.html">
							<img src="images/case/case-01.jpg">						
						</a>
						<p>内蒙古成吉思汗铜雕</p>
					</li>
					<li>
						<a href="case02.html">
							<img src="images/case/case-02.jpg">						
						</a>
						<p>贵州遵义水泥浮雕</p>
					</li>
					<li>
						<a href="case03.html">
							<img src="images/case/case-03.jpg">						
						</a>
						<p>银川玻璃钢装饰</p>
					</li>
					<li>
						<a href="case04.html">
							<img src="images/case/case-04.jpg">						
						</a>
						<p>秦皇岛太平天国展览馆</p>
					</li>
					<li>
						<a href="case05.html">
							<img src="images/case/case-05.jpg">		
						</a>
						<p>湖北大冶毛主席石雕像</p>
					</li>
					
				</ul>
			</div>
		</div>

		<!-- 产品中心 -->
		<div class="products">
			<div class="title">
				<h2>
					<img src="images/products/product-title.png">
				</h2>
			</div>	
			<div class="content">
				<div class="left">
					<h3>产品分类</h3>
					<ul>						
							<li>
								<a href="frp.html">
									玻璃钢
									<i class="fa fa-angle-right fa-lg"></i>
								</a>

							</li>
							<li>
								<a href="stainless.html">
									不锈钢
									<i class="fa fa-angle-right fa-lg"></i>
								</a>
							</li>
							<li>
								<a href="duantong.html">
									段铜
									<i class="fa fa-angle-right fa-lg"></i>
								</a>
							</li>
							<li>
								<a href="clay.html">
									泥塑
									<i class="fa fa-angle-right fa-lg"></i>
								</a>
							</li>
							<li>
								<a href="foam.html">
									泡沫雕塑
									<i class="fa fa-angle-right fa-lg"></i>
								</a>
							</li>
							<li>
								<a href="carving.html">
									石雕
									<i class="fa fa-angle-right fa-lg"></i>
								</a>
							</li>
							<li>
								<a href="cement.html">
									水泥雕塑
									<i class="fa fa-angle-right fa-lg"></i>
								</a>
							</li>
							<li>
								<a href="copper.html">
									铜雕
									<i class="fa fa-angle-right fa-lg"></i>
								</a>
							</li>
						</ul>
				</div>
				<div class="right">
					<ul>
						<li>
							<a href="frp.html">
								<img src="images/frp/frp1.jpg">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
						<li>
							<a href="carving.html">
								<img src="images/carving/carving4.jpg">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
						<li>
							<a href="copper.html">
								<img src="images/copper/case-03.jpg">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
						<li>
							<a href="copper.html">
								<img src="images/copper/copper12.jpg">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
						<li>
							<a href="cement.html">
								<img src="images/cement/case-05.jpg">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
						<li>
							<a href="clay.html">
								<img src="images/clay/clay4.jpg">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
						<li>
							<a href="duantong.html">
								<img src="images/duantong/duantong3.jpg">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
						<li>
							<a href="carving.html">
								<img src="images/carving/carving5.JPG">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
						<li>
							<a href="frp.html">
								<img src="images/frp/frp7.jpg">
								<span>业务洽谈电话：15630856998</span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<!-- 版权声明 -->
		<div class="footer">
			<div class="wraper">
				<div class="copyright">
					<p>曲阳县杰达雕塑有限公司</p>
					<p>业务电话：白经理：156 3085 6998</p>
					<p>地址：河北省曲阳县经济开发区</p>
					<p>邮箱：851336148@qq.com</p>
					<p>版权所有 : 曲阳县杰达雕塑有限公司</p>
				</div>
				<div class="code">
					<img src="images/erweima.png">
					<p>微信公众号</p>
				</div>
			</div>
		</div>

	</div>
	<script type="text/javascript" src="js/index.js"></script>
</body>
</html>